package db;

import java.sql.Connection;
import java.sql.DriverManager;


public class DBConnection {
	 public static Connection getConnection() {

	        Connection con = null;

	        try {

	            Class.forName("com.mysql.cj.jdbc.Driver");

	            con = DriverManager.getConnection(
	                    "jdbc:mysql://localhost:3306/smartbite",
	                    "root",
	                    "Baru@20004");

	            System.out.println("Database Connected Successfully");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return con;
	    }

	    public static void main(String[] args) {

	        getConnection();

	    }
	
}
