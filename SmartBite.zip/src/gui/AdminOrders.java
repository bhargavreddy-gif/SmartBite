package gui;

import db.DBConnection;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AdminOrders extends JFrame {

    JTextArea area;

    AdminOrders() {

        setTitle("Admin - View Orders");

        area = new JTextArea();

        area.setBounds(20, 20, 450, 300);

        add(area);

        setSize(500, 400);

        setLayout(null);

        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        displayOrders();
    }

    public void displayOrders() {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM orders";

            PreparedStatement pst = con.prepareStatement(query);

            ResultSet rs = pst.executeQuery();

            area.setText(
                    "ID\tFOOD\tQTY\tTOTAL\tSTATUS\n\n"
            );

            while(rs.next()) {

                area.append(
                        rs.getInt("order_id") + "\t" +
                        rs.getString("food_name") + "\t" +
                        rs.getInt("quantity") + "\t" +
                        rs.getDouble("total_price") + "\t" +
                        rs.getString("status") + "\n"
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new AdminOrders();

    }
}