package gui;

import db.DBConnection;

import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class FoodMenu extends JFrame {

    JTextArea area;

    FoodMenu() {

        setTitle("Food Menu");

        area = new JTextArea();

        area.setBounds(50, 50, 300, 250);

        add(area);

        setSize(400, 400);
        setLayout(null);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        displayMenu();
    }

    public void displayMenu() {

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM food_items";

            PreparedStatement pst = con.prepareStatement(query);

            ResultSet rs = pst.executeQuery();

            area.setText("ID\tFOOD\tPRICE\n\n");

            while (rs.next()) {

                area.append(
                        rs.getInt("id") + "\t" +
                        rs.getString("food_name") + "\t" +
                        rs.getDouble("price") + "\n"
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new FoodMenu();

    }
}