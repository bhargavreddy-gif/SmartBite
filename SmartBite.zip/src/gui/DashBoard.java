package gui;

import javax.swing.*;
import java.awt.event.*;

public class DashBoard extends JFrame implements ActionListener {

    JButton b1,b2,b3,b4;

    DashBoard() {

        b1 = new JButton("Menu");

        b2 = new JButton("Place Order");

        b3 = new JButton("Search Food");

        b4 = new JButton("Admin Orders");

        b1.setBounds(100,50,150,30);

        b2.setBounds(100,100,150,30);

        b3.setBounds(100,150,150,30);

        b4.setBounds(100,200,150,30);

        add(b1);

        add(b2);

        add(b3);

        add(b4);

        b1.addActionListener(this);

        b2.addActionListener(this);

        b3.addActionListener(this);

        b4.addActionListener(this);

        setSize(400,400);

        setLayout(null);

        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        if(e.getSource()==b1) {

            new FoodMenu();
        }

        else if(e.getSource()==b2) {

            new PlaceOrder2();
        }

        else if(e.getSource()==b3) {

            new SearchFood();
        }

        else {

            new AdminOrders();
        }
    }

    public static void main(String[] args) {

        new DashBoard();
    }
}