package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class RegisterForm extends JFrame implements ActionListener {

    JLabel l1, l2, l3;
    JTextField t1, t2;
    JPasswordField p1;
    JButton b1;

    RegisterForm() {

        setTitle("User Registration");

        l1 = new JLabel("Name");
        l2 = new JLabel("Email");
        l3 = new JLabel("Password");

        t1 = new JTextField();
        t2 = new JTextField();
        p1 = new JPasswordField();

        b1 = new JButton("Register");

        l1.setBounds(50, 50, 100, 30);
        l2.setBounds(50, 100, 100, 30);
        l3.setBounds(50, 150, 100, 30);

        t1.setBounds(150, 50, 150, 30);
        t2.setBounds(150, 100, 150, 30);
        p1.setBounds(150, 150, 150, 30);

        b1.setBounds(120, 220, 100, 30);

        add(l1);
        add(l2);
        add(l3);

        add(t1);
        add(t2);
        add(p1);

        add(b1);

        b1.addActionListener(this);

        setSize(400, 400);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        String name = t1.getText();
        String email = t2.getText();
        String password = p1.getText();

        try {

            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO users(name,email,password) VALUES(?,?,?)";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, name);
            pst.setString(2, email);
            pst.setString(3, password);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Registration Successful");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new RegisterForm();

    }
}