package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class SearchFood extends JFrame implements ActionListener {

    JTextField t1;

    JTextArea area;

    JButton b1;

    SearchFood() {

        t1 = new JTextField();

        area = new JTextArea();

        b1 = new JButton("Search");

        t1.setBounds(50,50,150,30);

        b1.setBounds(220,50,100,30);

        area.setBounds(50,120,300,200);

        add(t1);

        add(b1);

        add(area);

        b1.addActionListener(this);

        setSize(400,400);

        setLayout(null);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String food = t1.getText();

        try {

            Connection con =
                    DBConnection.getConnection();

            String q =
                    "select * from food_items where food_name=?";

            PreparedStatement pst =
                    con.prepareStatement(q);

            pst.setString(1,food);

            ResultSet rs =
                    pst.executeQuery();

            if(rs.next()) {

                area.setText(
                        "Food : " +
                        rs.getString("food_name")
                        +
                        "\nPrice : " +
                        rs.getDouble("price")
                );
            }

            else {

                area.setText("Food Not Found");
            }

        }

        catch(Exception ex) {

            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new SearchFood();
    }
}