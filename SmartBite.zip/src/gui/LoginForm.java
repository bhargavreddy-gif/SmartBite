package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginForm extends JFrame implements ActionListener {

    JLabel l1, l2;
    JTextField t1;
    JPasswordField p1;
    JButton b1;

    LoginForm() {

        setTitle("User Login");

        l1 = new JLabel("Email");
        l2 = new JLabel("Password");

        t1 = new JTextField();
        p1 = new JPasswordField();

        b1 = new JButton("Login");

        l1.setBounds(50, 50, 100, 30);
        l2.setBounds(50, 100, 100, 30);

        t1.setBounds(150, 50, 150, 30);
        p1.setBounds(150, 100, 150, 30);

        b1.setBounds(120, 180, 100, 30);

        add(l1);
        add(l2);

        add(t1);
        add(p1);

        add(b1);

        b1.addActionListener(this);

        setSize(400, 300);
        setLayout(null);
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        String email = t1.getText();
        String password = p1.getText();

        try {

            Connection con = DBConnection.getConnection();

            String query = "SELECT * FROM users WHERE email=? AND password=?";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, email);
            pst.setString(2, password);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                JOptionPane.showMessageDialog(this, "Login Successful");

            } else {

                JOptionPane.showMessageDialog(this, "Invalid Email or Password");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new LoginForm();

    }
}