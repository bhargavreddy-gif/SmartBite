package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PlaceOrder extends JFrame implements ActionListener {

    JLabel l1, l2;
    JTextField t1, t2;
    JButton b1;

    PlaceOrder() {

        setTitle("Place Order");

        l1 = new JLabel("Food Name");
        l2 = new JLabel("Quantity");

        t1 = new JTextField();
        t2 = new JTextField();

        b1 = new JButton("Order");

        l1.setBounds(50, 50, 100, 30);
        l2.setBounds(50, 100, 100, 30);

        t1.setBounds(150, 50, 150, 30);
        t2.setBounds(150, 100, 150, 30);

        b1.setBounds(120, 180, 100, 30);

        add(l1);
        add(l2);

        add(t1);
        add(t2);

        add(b1);

        b1.addActionListener(this);

        setSize(400, 300);
        setLayout(null);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        String food = t1.getText();

        int quantity = Integer.parseInt(t2.getText());

        double price = 0;

        if(food.equalsIgnoreCase("Burger")) {
            price = 120;
        }
        else if(food.equalsIgnoreCase("Pizza")) {
            price = 250;
        }
        else if(food.equalsIgnoreCase("Biryani")) {
            price = 180;
        }
        else if(food.equalsIgnoreCase("Shawarma")) {
            price = 150;
        }

        double total = quantity * price;

        try {

            Connection con = DBConnection.getConnection();

            String query = "INSERT INTO orders(user_name, food_name, quantity, total_price, status) VALUES(?,?,?,?,?)";

            PreparedStatement pst = con.prepareStatement(query);

            pst.setString(1, "Customer");
            pst.setString(2, food);
            pst.setInt(3, quantity);
            pst.setDouble(4, total);
            pst.setString(5, "Ordered");

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Order Placed\nTotal Price = " + total);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new PlaceOrder();

    }
}