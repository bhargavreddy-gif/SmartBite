package gui;

import javax.swing.*;

public class BillPage extends JFrame {

    JTextArea area;

    BillPage() {

        area = new JTextArea();

        area.setBounds(50,50,300,250);

        area.setText(
                "------ FOOD BILL ------\n\n" +
                "Food : Pizza\n" +
                "Quantity : 2\n" +
                "Total : 500\n\n" +
                "Thank You"
        );

        add(area);

        setSize(400,400);

        setLayout(null);

        setVisible(true);
    }

    public static void main(String[] args) {

        new BillPage();
    }
}