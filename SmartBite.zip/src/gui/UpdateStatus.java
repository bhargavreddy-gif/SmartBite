package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateStatus extends JFrame implements ActionListener {

    JLabel l1, l2;

    JTextField t1, t2;

    JButton b1;

    UpdateStatus() {

        setTitle("Update Order Status");

        l1 = new JLabel("Order ID");
        l2 = new JLabel("New Status");

        t1 = new JTextField();
        t2 = new JTextField();

        b1 = new JButton("Update");

        l1.setBounds(50, 50, 100, 30);
        l2.setBounds(50, 100, 100, 30);

        t1.setBounds(150, 50, 150, 30);
        t2.setBounds(150, 100, 150, 30);

        b1.setBounds(120, 180, 100, 30);

        add(l1);
        add(l2);

        add(t1);
        add(t2);

        add(b1);

        b1.addActionListener(this);

        setSize(400, 300);
        setLayout(null);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent e) {

        int id = Integer.parseInt(t1.getText());

        String status = t2.getText();

        try {

            Connection con = DBConnection.getConnection();

            String query =
                    "UPDATE orders SET status=? WHERE order_id=?";

            PreparedStatement pst =
                    con.prepareStatement(query);

            pst.setString(1, status);

            pst.setInt(2, id);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Status Updated Successfully");

        } catch (Exception ex) {

            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new UpdateStatus();
    }
}