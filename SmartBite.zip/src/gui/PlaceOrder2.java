package gui;

import db.DBConnection;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class PlaceOrder2 extends JFrame implements ActionListener {

    JComboBox<String> box;

    JTextField t1;

    JButton b1;

    PlaceOrder2() {

        String foods[] = {
                "Burger",
                "Pizza",
                "Biryani"
        };

        box = new JComboBox<>(foods);

        t1 = new JTextField();

        b1 = new JButton("Order");

        box.setBounds(100, 50, 150, 30);

        t1.setBounds(100, 100, 150, 30);

        b1.setBounds(120, 160, 100, 30);

        add(box);

        add(t1);

        add(b1);

        b1.addActionListener(this);

        setSize(400,300);

        setLayout(null);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {

        String food =
                box.getSelectedItem().toString();

        int qty =
                Integer.parseInt(t1.getText());

        double price = 0;

        if(food.equals("Burger"))
            price = 120;

        else if(food.equals("Pizza"))
            price = 250;

        else
            price = 180;

        double total = qty * price;

        try {

            Connection con =
                    DBConnection.getConnection();

            String q =
                    "insert into orders(user_name,food_name,quantity,total_price,status) values(?,?,?,?,?)";

            PreparedStatement pst =
                    con.prepareStatement(q);

            pst.setString(1,"Customer");

            pst.setString(2,food);

            pst.setInt(3,qty);

            pst.setDouble(4,total);

            pst.setString(5,"Ordered");

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Total = " + total);

        }

        catch(Exception ex) {

            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {

        new PlaceOrder2();
    }
}